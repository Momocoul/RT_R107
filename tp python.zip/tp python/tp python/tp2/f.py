print ("jour=")
j=input()
print ("heure=")
h=input()
print ("minutes=")
m=input()
print("le nombre de minutes écoulés depuis ",(j*24*60)+(h*60)+m)

