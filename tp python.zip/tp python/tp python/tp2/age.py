age=int(input("Quel age avez-vous: "))
print(f"votre année de naissance est : ",2022- age )
