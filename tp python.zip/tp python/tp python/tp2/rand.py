from random import randint
a= randint(0,100)
print(f"la valeur est : {a}")
