""" exo 3 permut 
a=input("Entrez la premiere  valeur : ")
b=input("Entrez la deuxieme  valeur : ")
c=input("Entrez la troisieme valeur : ")

print("Les valeurs entrees sont : a = " + a + ", b = " + b + " et c = " + c)
print("Permutation: a ==> b, b ==> c, c ==> a")
"""      *******************************************
         * Completez le programme a partir d'ici.
         *******************************************
"""
temp = a

a = c
c = b
b = temp

"""     *******************************************
         * Ne rien modifier apres cette ligne.
         *******************************************
"""

print("Les valeurs permutees sont : a = " + a + ", b = " + b + " et c = " + c)

BASE = 4 #nb personne
vacherin = 400.0 #g pour BASE
gruyere = 400.0 #g pour BASE
vin_blanc = 3 #dL pour BASE
ail = 2 #gousse pour BASE
pain = 400 #g pour BASE
arvine = 4 #bouteilles pour BASE

conv = int(input("Entrez le nombre de personne(s) conviées à la fondue moitié-moitié (dans les règles de l'art) : "))

ratio = conv / BASE

vacherin = vacherin * ratio
gruyere = gruyere * ratio
vin_blanc = vin_blanc * ratio
ail = ail * ratio
pain = pain * ratio
arvine = arvine * ratio

print(f"Pour faire une fondue fribourgeoise pour 3 personnes, il vous faut :\n"
      f"- {vacherin} gr de Vacherin Fribourgeois\n"
      f"- {gruyere} gr de Gruyère\n"
      f"- {vin_blanc} dl de vin blanc sec\n"
      f"- {ail} gousse(s) d'ail\n"
      f"- {pain} gr de pain\n"
      f"- {arvine} bouteille(s) de Petite Arvine, comme on dit «Beau pays, mais SEC !» ")


***

x = float(input("Entrez un nombre décimal : "))

if x == 2 or 2 < x < 3 or 0 < x < 1 or x == 1 or x == -10 or -10 < x < -2 or x == -2:
    print("x appartient à I")
else:
    print("x n'appartient pas à I")

    ****
nb = int(input("Entrez un nombre entier: "))

if nb == 0:
    print("Le nombre est zéro (et il est pair)")
elif nb > 0:
    if (nb % 2) == 0:
        print("Le nombre est positif et pair")
    else:
        print("Le nombre est positif et impair")
else:
    if (nb % 2) == 0:
        print("Le nombre est négatif et pair")
    else:
        print("Le nombre est négatif et impair")
        ****
import random

rand = random.randrange(0, 100, 1)
        # 0-49 = 50 ; 50-99 = 50

if rand < 50:
            print("Pile !")
else:
            print("Face !")
         ***
            
import random

rand = random.randrange(0, 100, 1)
# 0-49 = 50 ; 50-99 = 50

if rand < (200/3):
    print("Pile !")
else:
    print("Face !")            
            
            
            
            
"""