
x=int(input("donner x: "))
y=int(input("donner y: "))
a=x
x=y
y=a
print (f"apres permutation X:{x} et Y: {y} ")