nb=float(input("le nombre :"))

for i in range(1, 10+1):
    print(nb ,"*", i, "=", round(nb*i,2))
