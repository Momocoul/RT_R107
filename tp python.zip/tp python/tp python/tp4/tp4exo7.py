binome = ("login1", "login2")

print(f"L’étudiant {binome[0]} est en binome avec l’étudiant {binome[1]}")




























"""binome[1] = input("Changer de binome pour : ")
'tuple' object does not support item assignment
del(binome[1])
'tuple' object doesn't support item deletion
binome=(input(..), ...)
binome[2] = "login3"
'tuple' object does not support item assignment
"""