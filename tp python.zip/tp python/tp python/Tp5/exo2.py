while True:
    temptable=[]
    note=[]
    coef=[]
    total=0
    count=0
    test=0
    for i in range(5):
        temp=str(input(f"votre {i+1}e note et son coef: "))
        temptable=temp.split(" ")
        if len(temptable) != 2:
            print("les valeurs ou la syntaxe sont faussent!")
            break
        note.append(temptable[0])
        coef.append(temptable[1])
    for i in range(5):
        total=total+(float(note[i])*int(coef[i]))
        count=count+1
    total=total/count
    if total >= 10:
        for i in range(5):
            if float(note[i])<8:
                print("vous avez une note inférieur à 8 ")
                test=1
        if test==0:
            print("Félicitation vous etes admis" )
    else:
        print("vous etes pas admis ")