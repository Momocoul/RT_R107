prenom = []
nom = []
for n in range(1 ,3):
    prenom.append(str.lower(input(f"Entrez le {n}è prénom : ")))
    nom.append(str.lower((input(f"Entrez le {n}è nom   : "))))
for i in range(len(prenom) - 1):
    for j in range(i + 1, len(prenom)):
        if nom[j] == nom[i] and prenom[j] < prenom[i]:
                prenom[i], prenom[j] = prenom[j], prenom[i]
                nom[i], nom[j] = nom[j], nom[i]
        elif nom[j] < nom[i]:
            prenom[i], prenom[j] = prenom[j], prenom[i]
            nom[i], nom[j] = nom[j], nom[i]
for l in range(len(prenom)):
    print(f"{str.capitalize(prenom[l])} {str.upper(nom[l])}")

