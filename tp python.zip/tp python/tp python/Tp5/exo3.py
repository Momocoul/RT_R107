chaine = str.lower(input("Entrez une chaine de caractères : "))
chaine2 = ""
n = 0

for i in chaine:
    if i.isalpha() == True:
        chaine2 = chaine2 + i
   #else:
      #  print("contient des carateres non alpha")

x = len(chaine2)
z = x - 1
for j in range(int(x / 2)):
    if chaine2[j] != chaine2[z - j]:
        print("Ce n'est pas un palindrome !")
        n = 1
        break

if n == 0:
    print("C'est un palindrome !")
