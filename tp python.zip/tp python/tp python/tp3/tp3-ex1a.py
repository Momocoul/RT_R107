n=int(input("donner n: "))
s=0
for i in range(1,n+1):
    s+=i
    print (i)
print ("la somme est :", s)"""


"""
n=int(input("donner n: "))
while (n!=100):
    print("donner 100 pour sortir")
    n = int(input("donner n: "))
     if (n==100):
       break  
       """
"""
a=0
b=0
c=0
for i in range(0,10):
          n=float(input("donner N compris entre 0 et 20: "))
          if (n not in range(20)):
            n = float(input("redonner N compris entre 0 à 20: "))
            print(n)
         if (n<10):
               a+=1
         elif (n >= 10 or n < 15):
               b+= 1
         elif (n >= 15 ):
               c+= 1
print(f"on a {a} valeur inférieur strictement à 10, {b} valeurs supérieur ou égale à 10 et inférieur strictement à 15  et  {c} valeurs supérieur ou égale à 15  ")

"""
def numbSorting():
    ten = 0
    fifteen = 0
    twenty = 0
    for i in range(10):
        value = int(input(f"Please enter the {i + 1} integer: "))
        while value < 0 or value > 20:
            value = int(input(f"Please enter the {i + 1} integer: "))
        if 0 <= value < 10:
            ten += 1
        elif 10 <= value < 15:
            fifteen += 1
        elif 15 <= value <= 20:
            twenty += 1
        else:
            raise TypeError("erreur")
    print(f"There are: {ten} values in the interval [0;10[, {fifteen} in the interval [10;15[ and {twenty} in the "
          f"interval [15;20]")

numSorting()


"""def XSumCalculator():
    x = int(input("Please, enter an integer > 1 : "))
    n = 1
    s = 0
    while s <= x:
        s += n
        n += 1
    print("The largest valid number is", n - 2)
XSumCalculator()
"""
