from time import sleep
i=int(input("donner un nbr="))
while i>=0 :
    print (i)
    sleep(0.2)
    i-=1
