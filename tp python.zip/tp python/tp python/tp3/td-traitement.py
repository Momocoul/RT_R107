"""def Fact():
    n = int(input("donner le nbr  : "))
    s = 1
    for i in range(2, n + 1):
        s *= i
        print(s)
    print("The Factorial is", s, "with for")
Fact()

def Fact(n):
    if n==0 or n==1:
        return 1
    else:
        return n*Fact(n-1)

nbr = int(input("donner un nbre :  "))
print(Fact(nbr))

"""

def tri(tab):
    n=len(tab)
    for i in range(n):
        for j in range(0,n-i-1):
            if tab[j]>tab[j+1]:
                tab[j],tab[j+1]=tab[j+1],tab[j]
        print(tab)
    return tab


t=[17,4,12,10,6,0,1]
#tri(t)
#print(t)
print(tri(t))











"""
def compter(tab):
    t= [0]*(max(tab)+1)
    for v in tab:
        t[v] += 1
    for v in range(len(t)):
        if t[v] != 0:
            print(str(v)+" a "+str(urnes[v])+" occurrences");
            
            
            ***
            
            
def compterTri(tab):
    trie = sorted(tab)
    compteur = 1
    avant = None
    for v in trie:
        if v == avant:
            compteur += 1
        elif avant != None:
            print(str(avant)+" a "+str(compteur)+" occurrences")
            compteur = 1
        avant = v
    print(str(avant)+" a "+str(compteur)+" occurrences")            
            
            
            
            
            
            
            
            
            """